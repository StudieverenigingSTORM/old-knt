package vu.storm.touch.user;

public interface PinScreenListener {
  void pinCancel();
  
  boolean pinConfirm(String paramString);
  
  void pinDone();
}


/* Location:              /Users/nicholas/Desktop/old-knt/old-jar/program.jar!/vu/storm/touch/user/PinScreenListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */