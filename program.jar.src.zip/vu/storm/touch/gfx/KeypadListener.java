package vu.storm.touch.gfx;

public interface KeypadListener {
  void keypadPressed(Keypad paramKeypad, char paramChar);
}


/* Location:              /Users/nicholas/Desktop/old-knt/old-jar/program.jar!/vu/storm/touch/gfx/KeypadListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */