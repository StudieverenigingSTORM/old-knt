package vu.storm.touch.gfx;

public interface GraphicsConstants {
  public static final String DEFAULT_FONT = "Verdana";
  
  public static final int LONGPRESS_DELAY = 600;
  
  public static final int ERRORFLASH_DELAY = 1000;
  
  public static final int WARNINGFLASH_DELAY = 1000;
  
  public static final int GOODFLASH_DELAY = 1000;
}


/* Location:              /Users/nicholas/Desktop/old-knt/old-jar/program.jar!/vu/storm/touch/gfx/GraphicsConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */