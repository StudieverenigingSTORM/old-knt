package vu.storm.administration;

public abstract class IProduct {
  public abstract String getName();
  
  public abstract long getPrice();
  
  public abstract String getDescription();
}


/* Location:              /Users/nicholas/Desktop/old-knt/old-jar/program.jar!/vu/storm/administration/IProduct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */