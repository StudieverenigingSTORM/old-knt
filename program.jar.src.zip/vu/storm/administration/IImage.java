package vu.storm.administration;

public abstract class IImage {
  public abstract String getName();
  
  public abstract byte[] getData();
}


/* Location:              /Users/nicholas/Desktop/old-knt/old-jar/program.jar!/vu/storm/administration/IImage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */